$(document).ready(function(){

	$(function(){
		$(".main li").hover(
		function(){
			$(">.sub",this).slideDown(300);
		},
		function(){
			$(">.sub",this).slideUp(300);
		});
	});

});

