$(document).ready(function() {

var cities = ["NYC", "SF", "LA", "ATX", "SYD"];

cities.forEach(function(city){
  $("#city-type").append("<option value="+ city +">"+ city +"</option>");
});

	$("form").on("change", "#city-type",function(){
	    var city = $("#city-type").val();
	    switch(city) {
	    case "NYC":
	        $("body").attr("class","nyc");
	        break;
      	case "SF":
	        $("body").attr("class","sf");
	        break;
      	case "LA":
	        $("body").attr("class","la");
	        break;
      	case "ATX":
	        $("body").attr("class","austin");
	        break;
      	case "SYD":
	        $("body").attr("class","sydney");
	        break;
	}

});

}); //END doc.ready